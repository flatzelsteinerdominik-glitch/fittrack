# FitTrack – iPhone-Web-App (PWA)

FitTrack ist eine deutschsprachige, mobil optimierte Web-App für Training, Ernährung und Skincare. Sie kann in Safari zum iPhone-Home-Bildschirm hinzugefügt werden.

## Funktionen
- Trainingstage mit Datum, Notizen und Übungen (Sätze, Wiederholungen, kg)
- Essens-Chat mit OpenAI API und geschätzten Nährwerten
- Mahlzeiten-Log mit Tages-Summen
- Morgen- und Abendroutine für Skincare mit täglichem Abhaken
- Lokale Speicherung im Browser (localStorage)
- PWA-Manifest und Service Worker für installierbare Oberfläche und App-Shell-Cache
- JSON-Datenexport

## Lokal testen
Ein Service Worker benötigt HTTPS oder localhost. Im Projektordner:
```bash
python -m http.server 8000
```
Dann am PC `http://localhost:8000` öffnen. Die KI benötigt Internet und einen OpenAI API-Key.

## Auf iPhone bereitstellen (kostenloser Static-Hosting-Weg)
1. Lege ein privates oder öffentliches GitHub-Repository an.
2. Lade alle Dateien und den Ordner `icons` in das Repository.
3. Öffne im Repository **Settings → Pages**.
4. Wähle **Deploy from a branch**, Branch `main`, Ordner `/ (root)`, dann Save.
5. Warte, bis GitHub Pages eine HTTPS-Adresse anzeigt.
6. Öffne diese Adresse auf dem iPhone in **Safari**.
7. Tippe auf **Teilen → Zum Home-Bildschirm** und bestätige **Hinzufügen**.

Alternativ kann der Ordner auf einen HTTPS-Static-Host wie Netlify oder Cloudflare Pages hochgeladen werden.

## OpenAI API-Key
1. Erstelle einen Key unter https://platform.openai.com/api-keys.
2. Hinterlege bei Bedarf eine Zahlungsmethode / API-Guthaben.
3. Öffne FitTrack → Einstellungen und füge den Key ein.
4. Der Key wird in `localStorage` dieses Browsers gespeichert und nicht in den Projektdateien abgelegt.

**Sicherheit:** Diese reine Frontend-Version ruft die OpenAI API direkt aus dem Browser auf. Der API-Key ist dadurch für den Besitzer des Browsers und technisch versierte Nutzer des Geräts zugänglich. Verwende diese Version nur privat auf deinen eigenen Geräten. Stelle sie nicht als öffentliche App für andere Nutzer bereit. Für eine öffentliche Version muss die API-Anfrage über einen eigenen Server/Backend-Proxy laufen, der den Key geheim hält.

## Daten
Trainings, Mahlzeiten und Skincare-Produkte werden lokal im Browser gespeichert. Browserdaten löschen oder ein anderes Gerät verwenden bedeutet, dass diese Daten nicht automatisch mitwandern. Exportiere deine Daten in Einstellungen regelmäßig als JSON.

## Hinweis
Nährwerte sind grobe Schätzungen und keine medizinische oder ernährungswissenschaftliche Beratung. API-Nutzung wird separat über dein OpenAI-Konto abgerechnet.

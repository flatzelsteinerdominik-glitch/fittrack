const $ = (id) => document.getElementById(id);
const STORE = "fittrack-data-v1";
const KEY_STORE = "fittrack-openai-key";
const today = () => new Date().toISOString().slice(0,10);
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()+Math.random()));
let data = JSON.parse(localStorage.getItem(STORE) || '{"workouts":[],"meals":[],"products":[]}');
let activeRoutine = "morning";
let selectedWorkout = null;
let pendingMeal = null;
let chatHistory = [];

function save(){ localStorage.setItem(STORE, JSON.stringify(data)); }
function escapeHTML(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function toast(msg){$("toast").textContent=msg;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2400);}
function fmtDate(d){return new Date(d+"T12:00:00").toLocaleDateString("de-AT",{day:"2-digit",month:"long",year:"numeric"});}
function showTab(tab){document.querySelectorAll(".view").forEach(v=>v.classList.toggle("active",v.id==="view-"+tab));document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));}
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>showTab(b.dataset.tab)));
$("todayLabel").textContent=new Date().toLocaleDateString("de-AT",{weekday:"short",day:"2-digit",month:"short"});

function renderWorkouts(){
 const list=$("workoutList");const sorted=[...data.workouts].sort((a,b)=>b.date.localeCompare(a.date));
 $("workoutCount").textContent=data.workouts.length;
 const weekStart=new Date();weekStart.setDate(weekStart.getDate()-((weekStart.getDay()+6)%7));weekStart.setHours(0,0,0,0);
 $("weekCount").textContent=data.workouts.filter(w=>new Date(w.date+"T12:00:00")>=weekStart).length;
 list.innerHTML=sorted.length?sorted.map(w=>`<div class="list-card clickable" data-open-workout="${w.id}"><div class="list-icon">▦</div><div class="list-main"><strong>${escapeHTML(w.name)}</strong><span>${fmtDate(w.date)} · ${w.exercises.length} Übungen</span></div><span class="list-side">›</span><button class="delete-btn" data-delete-workout="${w.id}" aria-label="Training löschen">×</button></div>`).join(""):`<div class="empty-state"><b>Noch keine Trainingstage</b>Lege deine erste Einheit an.</div>`;
}
$("newWorkoutBtn").onclick=()=>{$("workoutName").value="";$("workoutDate").value=today();$("workoutNotes").value="";$("workoutDialog").showModal();};
document.querySelectorAll("#workoutPicks button").forEach(b=>b.onclick=()=>$("workoutName").value=b.textContent);
$("workoutForm").addEventListener("submit",e=>{if(e.submitter?.value!=="save")return;e.preventDefault();const w={id:uid(),name:$("workoutName").value.trim(),date:$("workoutDate").value,notes:$("workoutNotes").value,exercises:[]};if(!w.name||!w.date)return;data.workouts.push(w);save();$("workoutDialog").close();renderWorkouts();toast("Training gespeichert.");});
$("workoutList").addEventListener("click",e=>{const del=e.target.closest("[data-delete-workout]");if(del){e.stopPropagation();if(confirm("Trainingstag und alle Übungen löschen?")){data.workouts=data.workouts.filter(w=>w.id!==del.dataset.deleteWorkout);save();renderWorkouts();}return;}const card=e.target.closest("[data-open-workout]");if(card)openWorkout(card.dataset.openWorkout);});
function openWorkout(id){selectedWorkout=data.workouts.find(w=>w.id===id);if(!selectedWorkout)return;$("detailTitle").textContent=selectedWorkout.name;$("detailDate").textContent=fmtDate(selectedWorkout.date);$("detailNotes").value=selectedWorkout.notes||"";renderExercises();$("detailDialog").showModal();}
function renderExercises(){const w=selectedWorkout;$("exerciseList").innerHTML=w.exercises.length?w.exercises.map(x=>`<div class="list-card"><div class="list-icon">↗</div><div class="list-main"><strong>${escapeHTML(x.name)}</strong><span>${x.sets} Sätze × ${x.reps} Wdh. · ${x.weight} kg</span></div><button class="delete-btn" data-delete-exercise="${x.id}" aria-label="Übung löschen">×</button></div>`).join(""):`<div class="empty-state">Noch keine Übungen hinzugefügt.</div>`;}
$("detailForm").addEventListener("submit",e=>{if(e.submitter?.value!=="save")return;e.preventDefault();selectedWorkout.notes=$("detailNotes").value;save();$("detailDialog").close();renderWorkouts();toast("Training aktualisiert.");});
$("addExerciseBtn").onclick=()=>{$("exerciseName").value="";$("exerciseSets").value=3;$("exerciseReps").value=10;$("exerciseWeight").value=0;$("exerciseDialog").showModal();};
$("exerciseForm").addEventListener("submit",e=>{if(e.submitter?.value!=="save")return;e.preventDefault();selectedWorkout.exercises.push({id:uid(),name:$("exerciseName").value.trim(),sets:+$("exerciseSets").value,reps:+$("exerciseReps").value,weight:+$("exerciseWeight").value});save();$("exerciseDialog").close();renderExercises();renderWorkouts();});
$("exerciseList").addEventListener("click",e=>{const b=e.target.closest("[data-delete-exercise]");if(!b)return;selectedWorkout.exercises=selectedWorkout.exercises.filter(x=>x.id!==b.dataset.deleteExercise);save();renderExercises();renderWorkouts();});

function renderMeals(){
 const meals=data.meals.filter(m=>m.date===today());const sum=k=>meals.reduce((a,m)=>a+(Number(m[k])||0),0);
 $("dayKcal").textContent=Math.round(sum("kcal"));$("dayProtein").textContent=Math.round(sum("protein"))+" g";$("dayCarbs").textContent=Math.round(sum("carbs"))+" g";$("dayFat").textContent=Math.round(sum("fat"))+" g";$("mealCount").textContent=meals.length+" Einträge";
 $("mealLog").innerHTML=meals.length?meals.map(m=>`<div class="list-card"><div class="list-icon">◉</div><div class="list-main"><strong>${escapeHTML(m.title)}</strong><span>${Math.round(m.kcal)} kcal · P ${Math.round(m.protein)} g · KH ${Math.round(m.carbs)} g · F ${Math.round(m.fat)} g</span></div><button class="delete-btn" data-delete-meal="${m.id}" aria-label="Mahlzeit löschen">×</button></div>`).join(""):`<div class="empty-state">Noch keine Mahlzeiten für heute gespeichert.</div>`;
}
$("mealLog").addEventListener("click",e=>{const b=e.target.closest("[data-delete-meal]");if(!b)return;data.meals=data.meals.filter(m=>m.id!==b.dataset.deleteMeal);save();renderMeals();});
function addChatBubble(role,text,meal=null){const div=document.createElement("div");div.className="bubble "+role;div.textContent=text;if(role==="assistant"&&meal){const info=document.createElement("div");info.className="meal-result";info.textContent=`${Math.round(meal.kcal)} kcal · Protein ${meal.protein} g · Kohlenhydrate ${meal.carbs} g · Fett ${meal.fat} g`;div.appendChild(info);const btn=document.createElement("button");btn.className="add-meal-btn";btn.textContent="＋ Zum Tag hinzufügen";btn.onclick=()=>{data.meals.push({id:uid(),date:today(),title:meal.title,kcal:+meal.kcal,protein:+meal.protein,carbs:+meal.carbs,fat:+meal.fat});save();renderMeals();btn.textContent="✓ Zum Tag hinzugefügt";btn.disabled=true;};div.appendChild(btn);} $("chatMessages").appendChild(div);$("chatMessages").scrollTop=$("chatMessages").scrollHeight;}
$("chatForm").addEventListener("submit",async e=>{e.preventDefault();const input=$("foodInput"),msg=input.value.trim();if(!msg)return;const key=localStorage.getItem(KEY_STORE);if(!key){toast("Bitte zuerst deinen OpenAI API-Key in Einstellungen speichern.");showTab("settings");return;}input.value="";addChatBubble("user",msg);const loading=document.createElement("div");loading.className="bubble assistant";loading.textContent="Ich schätze die Nährwerte …";$("chatMessages").appendChild(loading);const send=$(".send-btn");send.disabled=true;
 try{
  const schema={type:"object",additionalProperties:false,properties:{reply:{type:"string"},meal:{anyOf:[{type:"object",additionalProperties:false,properties:{title:{type:"string"},kcal:{type:"number"},protein:{type:"number"},carbs:{type:"number"},fat:{type:"number"}},required:["title","kcal","protein","carbs","fat"]},{type:"null"}]}},required:["reply","meal"]};
  const response=await fetch("https://api.openai.com/v1/responses",{method:"POST",headers:{"Content-Type":"application/json","Authorization":"Bearer "+key},body:JSON.stringify({model:"gpt-4o-mini",instructions:"Du bist FitTrack, ein freundlicher Ernährungsassistent. Antworte ausschließlich auf Deutsch und ausschließlich im vorgegebenen JSON-Schema. Schätze bei konkret genannten Mahlzeiten realistische grobe Nährwerte für die gesamte genannte Portion. kcal als Zahl, Protein/Kohlenhydrate/Fett in Gramm. Bei unklaren Mengen nutze vernünftige Durchschnittsportionen und weise in reply kurz auf die Schätzung hin. Wenn kein konkretes Essen genannt wurde, meal:null. Keine medizinischen Ratschläge.",input:msg,text:{format:{type:"json_schema",name:"fittrack_meal",strict:true,schema}}})});
  if(!response.ok){const err=await response.json().catch(()=>({}));throw new Error(err.error?.message||`API-Fehler (${response.status})`);}
  const result=await response.json();const output=(result.output||[]).flatMap(o=>o.content||[]).find(c=>c.type==="output_text")?.text;if(!output)throw new Error("Die KI hat keine verwertbare Antwort gesendet.");const parsed=JSON.parse(output);loading.remove();addChatBubble("assistant",parsed.reply,parsed.meal);
 }catch(err){loading.remove();addChatBubble("assistant","Das hat leider nicht funktioniert: "+err.message+". Prüfe deinen API-Key und deine Internetverbindung.");}
 finally{send.disabled=false;}
});

document.querySelectorAll(".switch-btn").forEach(b=>b.onclick=()=>{activeRoutine=b.dataset.routine;document.querySelectorAll(".switch-btn").forEach(x=>x.classList.toggle("active",x===b));renderProducts();});
$("newProductBtn").onclick=()=>{$("productName").value="";$("productBrand").value="";$("productRoutine").value=activeRoutine;$("productDialog").showModal();};
$("productForm").addEventListener("submit",e=>{if(e.submitter?.value!=="save")return;e.preventDefault();data.products.push({id:uid(),name:$("productName").value.trim(),brand:$("productBrand").value.trim(),step:$("productStep").value,routine:$("productRoutine").value,doneDate:""});save();$("productDialog").close();renderProducts();toast("Produkt hinzugefügt.");});
function renderProducts(){const items=data.products.filter(p=>p.routine===activeRoutine);const done=items.filter(p=>p.doneDate===today()).length;$("routineProgressText").textContent=`${done} von ${items.length} erledigt`;$("routineProgressBar").style.width=(items.length?done/items.length*100:0)+"%";$("productList").innerHTML=items.length?items.map(p=>`<div class="list-card"><button class="check-product ${p.doneDate===today()?"done":""}" data-toggle-product="${p.id}" aria-label="Produkt abhaken">${p.doneDate===today()?"✓":""}</button><div class="list-main"><strong>${escapeHTML(p.name)}</strong><span>${escapeHTML(p.brand||"Keine Marke")} · ${escapeHTML(p.step)}</span></div><button class="delete-btn" data-delete-product="${p.id}" aria-label="Produkt löschen">×</button></div>`).join(""):`<div class="empty-state"><b>Deine Routine ist noch leer</b>Füge deine ersten Pflegeprodukte hinzu.</div>`;}
$("productList").addEventListener("click",e=>{const t=e.target.closest("[data-toggle-product]");const d=e.target.closest("[data-delete-product]");if(t){const p=data.products.find(x=>x.id===t.dataset.toggleProduct);p.doneDate=p.doneDate===today()?"":today();save();renderProducts();}if(d){data.products=data.products.filter(x=>x.id!==d.dataset.deleteProduct);save();renderProducts();}});

$("saveKeyBtn").onclick=()=>{const key=$("apiKey").value.trim();if(!key){toast("Bitte einen API-Key eingeben.");return;}localStorage.setItem(KEY_STORE,key);$("apiKey").value="";$("keyStatus").textContent="✓ API-Key auf diesem Gerät gespeichert.";toast("API-Key gespeichert.");};
$("toggleKey").onclick=()=>{$("apiKey").type=$("apiKey").type==="password"?"text":"password";};
if(localStorage.getItem(KEY_STORE))$("keyStatus").textContent="✓ Ein API-Key ist auf diesem Gerät gespeichert.";
$("exportBtn").onclick=()=>{const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="fittrack-daten.json";a.click();URL.revokeObjectURL(a.href);};
$("clearDataBtn").onclick=()=>{if(confirm("Wirklich alle Trainings, Mahlzeiten und Produkte löschen?")){data={workouts:[],meals:[],products:[]};save();renderAll();toast("Lokale Daten gelöscht.");}};
function renderAll(){renderWorkouts();renderMeals();renderProducts();}
renderAll();
if("serviceWorker" in navigator && location.protocol.startsWith("http"))window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
